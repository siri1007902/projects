FARMER SUPPORT COMPLETE

1. Extract this ZIP.
2. Open folder in VS Code.
3. Right-click index.html -> Open with Live Server.
4. Test English, Telugu and Hindi from the language dropdown.
5. Do not mix old JS/HTML files with these files. Replace the whole project folder.

Includes: Home, 15 crops, pests & diseases, natural farming, 8 government schemes, voice assistant, help, responsive CSS and common multilingual system.

Safety: pesticide/fertilizer text is general. Exact dose must come from the product label and local agricultural recommendation.


UPDATED CSP FEATURES
--------------------
1. Home page now includes a realistic agriculture photo showcase for paddy fields, cotton fields and an Indian farm landscape.
2. Help page now includes verified farmer-support contacts, agriculture department information, officer directory links and official sources.
3. Call buttons use tel: links for mobile-friendly dialing.
4. The website keeps English, Telugu and Hindi language switching.
5. Agriculture photographs are referenced from Wikimedia Commons and source/licensing links are listed on the Help page.
