const translations={
  "brand": {
    "en": "Farmer Support",
    "te": "రైతు సహాయ కేంద్రం",
    "hi": "किसान सहायता"
  },
  "home": {
    "en": "Home",
    "te": "హోమ్",
    "hi": "होम"
  },
  "crops": {
    "en": "Crops",
    "te": "పంటలు",
    "hi": "फसलें"
  },
  "pests": {
    "en": "Pests & Diseases",
    "te": "తెగుళ్లు & వ్యాధులు",
    "hi": "कीट एवं रोग"
  },
  "naturalFarming": {
    "en": "Natural Farming",
    "te": "సహజ వ్యవసాయం",
    "hi": "प्राकृतिक खेती"
  },
  "schemes": {
    "en": "Government Schemes",
    "te": "ప్రభుత్వ పథకాలు",
    "hi": "सरकारी योजनाएँ"
  },
  "assistant": {
    "en": "🎤 Assistant",
    "te": "🎤 సహాయకుడు",
    "hi": "🎤 सहायक"
  },
  "help": {
    "en": "📞 Help",
    "te": "📞 సహాయం",
    "hi": "📞 सहायता"
  },
  "siteTitle": {
    "en": "Farmer Support",
    "te": "రైతు సహాయ కేంద్రం",
    "hi": "किसान सहायता"
  },
  "heroTitle": {
    "en": "Welcome to Farmer Support",
    "te": "రైతు సహాయ కేంద్రానికి స్వాగతం",
    "hi": "किसान सहायता में आपका स्वागत है"
  },
  "heroSubtitle": {
    "en": "A simple digital platform for agricultural information, awareness and support.",
    "te": "వ్యవసాయ సమాచారం, అవగాహన మరియు సహాయం కోసం సరళమైన డిజిటల్ వేదిక.",
    "hi": "कृषि जानकारी, जागरूकता और सहायता के लिए सरल डिजिटल मंच।"
  },
  "exploreCrops": {
    "en": "🌾 Explore Crops",
    "te": "🌾 పంటలను చూడండి",
    "hi": "🌾 फसलें देखें"
  },
  "askAssistant": {
    "en": "🎤 Ask Assistant",
    "te": "🎤 సహాయకుడిని అడగండి",
    "hi": "🎤 सहायक से पूछें"
  },
  "farmerServices": {
    "en": "Farmer Services",
    "te": "రైతు సేవలు",
    "hi": "किसान सेवाएँ"
  },
  "servicesSub": {
    "en": "Useful agricultural information in one place.",
    "te": "ఉపయోగకరమైన వ్యవసాయ సమాచారాన్ని ఒకే చోట.",
    "hi": "उपयोगी कृषि जानकारी एक ही जगह।"
  },
  "cropInfo": {
    "en": "Crop Information",
    "te": "పంటల సమాచారం",
    "hi": "फसल जानकारी"
  },
  "cropInfoSub": {
    "en": "Season, soil, water, fertilizers and crop protection.",
    "te": "కాలం, నేల, నీరు, ఎరువులు మరియు పంట రక్షణ.",
    "hi": "मौसम, मिट्टी, पानी, उर्वरक और फसल सुरक्षा।"
  },
  "pestInfo": {
    "en": "Pests & Diseases",
    "te": "తెగుళ్లు & వ్యాధులు",
    "hi": "कीट एवं रोग"
  },
  "pestInfoSub": {
    "en": "Identify common problems and learn safe management.",
    "te": "సాధారణ సమస్యలను గుర్తించి సురక్షిత నిర్వహణ తెలుసుకోండి.",
    "hi": "सामान्य समस्याएँ पहचानें और सुरक्षित प्रबंधन सीखें।"
  },
  "naturalInfo": {
    "en": "Natural Farming",
    "te": "సహజ వ్యవసాయం",
    "hi": "प्राकृतिक खेती"
  },
  "naturalInfoSub": {
    "en": "Low-input, soil-friendly farming practices.",
    "te": "తక్కువ పెట్టుబడితో నేలకు అనుకూలమైన వ్యవసాయ పద్ధతులు.",
    "hi": "कम लागत और मिट्टी के अनुकूल खेती की पद्धतियाँ।"
  },
  "schemeInfo": {
    "en": "Government Schemes",
    "te": "ప్రభుత్వ పథకాలు",
    "hi": "सरकारी योजनाएँ"
  },
  "schemeInfoSub": {
    "en": "Major farmer support schemes and official links.",
    "te": "ప్రధాన రైతు సంక్షేమ పథకాలు మరియు అధికారిక లింకులు.",
    "hi": "प्रमुख किसान सहायता योजनाएँ और आधिकारिक लिंक।"
  },
  "voiceInfo": {
    "en": "Voice Assistant",
    "te": "వాయిస్ సహాయకుడు",
    "hi": "वॉइस सहायक"
  },
  "voiceInfoSub": {
    "en": "Ask questions using your voice or keyboard.",
    "te": "వాయిస్ లేదా కీబోర్డ్‌తో ప్రశ్నలు అడగండి.",
    "hi": "आवाज़ या कीबोर्ड से प्रश्न पूछें।"
  },
  "helpSub": {
    "en": "Project guidance, useful contacts and safe-use notes.",
    "te": "ప్రాజెక్ట్ మార్గదర్శకత్వం, ఉపయోగకరమైన సంప్రదింపులు మరియు భద్రతా సూచనలు.",
    "hi": "परियोजना मार्गदर्शन, उपयोगी संपर्क और सुरक्षा सुझाव।"
  },
  "whyTitle": {
    "en": "Why Farmer Support?",
    "te": "రైతు సహాయం ఎందుకు?",
    "hi": "किसान सहायता क्यों?"
  },
  "multiLang": {
    "en": "Multilingual",
    "te": "బహుభాషా",
    "hi": "बहुभाषी"
  },
  "multiLangSub": {
    "en": "English, Telugu and Hindi support across the website.",
    "te": "వెబ్‌సైట్ అంతటా ఇంగ్లీష్, తెలుగు మరియు హిందీ భాషల మద్దతు.",
    "hi": "पूरी वेबसाइट पर अंग्रेज़ी, तेलुगु और हिंदी का समर्थन।"
  },
  "mobileFriendly": {
    "en": "Mobile Friendly",
    "te": "మొబైల్ అనుకూలం",
    "hi": "मोबाइल अनुकूल"
  },
  "mobileFriendlySub": {
    "en": "Simple layout designed for phones and computers.",
    "te": "ఫోన్‌లు మరియు కంప్యూటర్ల కోసం సరళమైన రూపకల్పన.",
    "hi": "फोन और कंप्यूटर के लिए सरल डिजाइन।"
  },
  "safeAdvice": {
    "en": "Safe Guidance",
    "te": "సురక్షిత మార్గదర్శకత్వం",
    "hi": "सुरक्षित मार्गदर्शन"
  },
  "safeAdviceSub": {
    "en": "Use labels and local agricultural advice before applying inputs.",
    "te": "ఇన్‌పుట్‌లు ఉపయోగించే ముందు లేబుల్ మరియు స్థానిక వ్యవసాయ సలహాను పాటించండి.",
    "hi": "इनपुट इस्तेमाल करने से पहले लेबल और स्थानीय कृषि सलाह का पालन करें।"
  },
  "fieldShowcaseTitle":{"en":"🌾 Agriculture Around Us","te":"🌾 మన చుట్టూ వ్యవసాయం","hi":"🌾 हमारे आसपास की कृषि"},
  "fieldShowcaseSub":{"en":"Real farm landscapes that make the platform familiar and welcoming for farmers.","te":"రైతులకు వెబ్‌సైట్‌ను మరింత పరిచయంగా మరియు ఆహ్లాదకరంగా చేసే నిజమైన వ్యవసాయ దృశ్యాలు.","hi":"किसानों के लिए प्लेटफ़ॉर्म को परिचित और स्वागतपूर्ण बनाने वाले वास्तविक कृषि दृश्य।"},
  "paddyField":{"en":"Paddy Fields","te":"వరి పొలాలు","hi":"धान के खेत"},
  "paddyFieldSub":{"en":"Rice-growing landscapes of India","te":"భారతదేశంలోని వరి సాగు దృశ్యాలు","hi":"भारत के धान उगाने वाले खेत"},
  "cottonField":{"en":"Cotton Fields","te":"పత్తి పొలాలు","hi":"कपास के खेत"},
  "cottonFieldSub":{"en":"Cotton crop and field awareness","te":"పత్తి పంట మరియు పొలాల అవగాహన","hi":"कपास की फसल और खेत की जानकारी"},
  "farmLandscape":{"en":"Indian Farm Landscape","te":"భారతీయ వ్యవసాయ దృశ్యం","hi":"भारतीय कृषि दृश्य"},
  "farmLandscapeSub":{"en":"A friendly view of agricultural life","te":"వ్యవసాయ జీవనానికి ఆహ్లాదకరమైన దృశ్యం","hi":"कृषि जीवन का सुंदर दृश्य"},
  "imageCredit":{"en":"Images: Wikimedia Commons. See Help page for source and licensing details.","te":"చిత్రాలు: Wikimedia Commons. మూలం మరియు లైసెన్స్ వివరాల కోసం సహాయం పేజీని చూడండి.","hi":"चित्र: Wikimedia Commons. स्रोत और लाइसेंस विवरण के लिए सहायता पृष्ठ देखें।"},
  "farmerHelplineTitle":{"en":"Farmer Helpline","te":"రైతు హెల్ప్‌లైన్","hi":"किसान हेल्पलाइन"},
  "farmerHelplineSub":{"en":"Get agriculture-related guidance in local languages.","te":"స్థానిక భాషల్లో వ్యవసాయ సంబంధిత మార్గదర్శకత్వం పొందండి.","hi":"स्थानीय भाषाओं में कृषि संबंधी मार्गदर्शन प्राप्त करें।"},
  "callKcc":{"en":"Call 1800-180-1551","te":"1800-180-1551 కు కాల్ చేయండి","hi":"1800-180-1551 पर कॉल करें"},
  "kccTitle":{"en":"Kisan Call Centre","te":"కిసాన్ కాల్ సెంటర్","hi":"किसान कॉल सेंटर"},
  "kccText":{"en":"Toll-free national farmer guidance service for agriculture and allied-sector questions.","te":"వ్యవసాయం మరియు అనుబంధ రంగాల ప్రశ్నలకు టోల్-ఫ్రీ జాతీయ రైతు మార్గదర్శక సేవ.","hi":"कृषि और संबद्ध क्षेत्रों के प्रश्नों के लिए टोल-फ्री राष्ट्रीय किसान मार्गदर्शन सेवा।"},
  "kccHours":{"en":"Available 6:00 AM–10:00 PM, all seven days.","te":"ప్రతి రోజు ఉదయం 6:00 నుండి రాత్రి 10:00 వరకు అందుబాటులో ఉంటుంది.","hi":"सप्ताह के सातों दिन सुबह 6:00 से रात 10:00 बजे तक उपलब्ध।"},
  "callNow":{"en":"📞 Call Now","te":"📞 ఇప్పుడే కాల్ చేయండి","hi":"📞 अभी कॉल करें"},
  "apAgriTitle":{"en":"Andhra Pradesh Agriculture Department","te":"ఆంధ్రప్రదేశ్ వ్యవసాయ శాఖ","hi":"आंध्र प्रदेश कृषि विभाग"},
  "apAgriText":{"en":"Commissioner & Director of Agriculture, Andhra Pradesh.","te":"ఆంధ్రప్రదేశ్ వ్యవసాయ కమిషనర్ & డైరెక్టర్ కార్యాలయం.","hi":"आंध्र प्रदेश के कृषि आयुक्त एवं निदेशक का कार्यालय।"},
  "callOffice":{"en":"📞 Call Office","te":"📞 కార్యాలయానికి కాల్ చేయండి","hi":"📞 कार्यालय को कॉल करें"},
  "apIntegratedTitle":{"en":"AP Integrated Call Centre","te":"ఏపీ ఇంటిగ్రేటెడ్ కాల్ సెంటర్","hi":"एपी इंटीग्रेटेड कॉल सेंटर"},
  "apIntegratedText":{"en":"Use the Andhra Pradesh integrated farmer-support contact when you need state-level assistance.","te":"రాష్ట్ర స్థాయి సహాయం అవసరమైనప్పుడు ఆంధ్రప్రదేశ్ సమగ్ర రైతు సహాయ సంప్రదింపును ఉపయోగించండి.","hi":"राज्य स्तर की सहायता के लिए आंध्र प्रदेश के एकीकृत किसान सहायता संपर्क का उपयोग करें।"},
  "officerTitle":{"en":"Agriculture Officers & District Contacts","te":"వ్యవసాయ అధికారులు & జిల్లా సంప్రదింపులు","hi":"कृषि अधिकारी एवं जिला संपर्क"},
  "officerText":{"en":"For a field visit, crop inspection, soil testing or district-level guidance, contact the Agriculture Department office in your district. Official Andhra Pradesh Agriculture Department pages publish district Project Director (ATMA), Joint Director, Assistant Director and Agriculture Officer contacts.","te":"పొలం సందర్శన, పంట పరిశీలన, నేల పరీక్ష లేదా జిల్లా స్థాయి మార్గదర్శకత్వం కోసం మీ జిల్లాలోని వ్యవసాయ శాఖ కార్యాలయాన్ని సంప్రదించండి. అధికారిక ఆంధ్రప్రదేశ్ వ్యవసాయ శాఖ వెబ్‌సైట్‌లో ATMA ప్రాజెక్ట్ డైరెక్టర్, సంయుక్త, సహాయ మరియు వ్యవసాయ అధికారుల సంప్రదింపులు ఉన్నాయి.","hi":"खेत निरीक्षण, फसल जांच, मिट्टी परीक्षण या जिला स्तर की सलाह के लिए अपने जिले के कृषि विभाग कार्यालय से संपर्क करें। आधिकारिक आंध्र प्रदेश कृषि विभाग की वेबसाइट पर ATMA परियोजना निदेशक, संयुक्त निदेशक, सहायक निदेशक और कृषि अधिकारी के संपर्क उपलब्ध हैं।"},
  "viewOfficerList":{"en":"📋 View Official Officer Directory","te":"📋 అధికారిక అధికారుల జాబితా చూడండి","hi":"📋 आधिकारिक अधिकारी सूची देखें"},
  "sourcesTitle":{"en":"Official Sources","te":"అధికారిక మూలాలు","hi":"आधिकारिक स्रोत"},
  "imageSourcesTitle":{"en":"Realistic Agriculture Images","te":"వాస్తవిక వ్యవసాయ చిత్రాలు","hi":"वास्तविक कृषि चित्र"},
  "imageSourcesText":{"en":"The home-page field photographs are sourced from Wikimedia Commons and are used because their licensing information is publicly available. The project credits the photographers and links to the source pages.","te":"హోమ్ పేజీలోని పొలాల ఫోటోలు Wikimedia Commons నుండి తీసుకోబడ్డాయి. వాటి లైసెన్స్ సమాచారం బహిరంగంగా అందుబాటులో ఉంది. ప్రాజెక్ట్‌లో ఫోటోగ్రాఫర్లకు క్రెడిట్ మరియు మూల పేజీల లింకులు ఇవ్వబడ్డాయి.","hi":"होम पेज की खेतों की तस्वीरें Wikimedia Commons से ली गई हैं। उनकी लाइसेंस जानकारी सार्वजनिक रूप से उपलब्ध है। प्रोजेक्ट में फोटोग्राफरों को क्रेडिट और स्रोत पृष्ठों के लिंक दिए गए हैं।"},
  "footer": {
    "en": "Farmer Support Application • Agriculture Awareness & Support",
    "te": "రైతు సహాయ అప్లికేషన్ • వ్యవసాయ అవగాహన & సహాయం",
    "hi": "किसान सहायता एप्लिकेशन • कृषि जागरूकता एवं सहायता"
  },
  "cropPageTitle": {
    "en": "🌾 Crop Information",
    "te": "🌾 పంటల సమాచారం",
    "hi": "🌾 फसल जानकारी"
  },
  "cropPageSub": {
    "en": "Select a crop to learn about season, soil, water, fertilizers, pesticides and good practices.",
    "te": "కాలం, నేల, నీరు, ఎరువులు, పురుగుమందులు మరియు మంచి పద్ధతుల గురించి తెలుసుకోవడానికి పంటను ఎంచుకోండి.",
    "hi": "मौसम, मिट्टी, पानी, उर्वरक, कीटनाशक और अच्छी पद्धतियों के बारे में जानने के लिए फसल चुनें।"
  },
  "searchCrop": {
    "en": "🔍 Search crop...",
    "te": "🔍 పంటను వెతకండి...",
    "hi": "🔍 फसल खोजें..."
  },
  "selectCrop": {
    "en": "🌱 Select a crop",
    "te": "🌱 పంటను ఎంచుకోండి",
    "hi": "🌱 फसल चुनें"
  },
  "pestPageTitle": {
    "en": "🐛 Pests & Diseases",
    "te": "🐛 తెగుళ్లు & వ్యాధులు",
    "hi": "🐛 कीट एवं रोग"
  },
  "pestPageSub": {
    "en": "Common crop problems, symptoms and safer management options.",
    "te": "సాధారణ పంట సమస్యలు, లక్షణాలు మరియు సురక్షిత నిర్వహణ మార్గాలు.",
    "hi": "सामान्य फसल समस्याएँ, लक्षण और सुरक्षित प्रबंधन विकल्प।"
  },
  "searchPest": {
    "en": "🔍 Search pest or disease...",
    "te": "🔍 తెగులు లేదా వ్యాధిని వెతకండి...",
    "hi": "🔍 कीट या रोग खोजें..."
  },
  "naturalPageTitle": {
    "en": "🌱 Natural Farming",
    "te": "🌱 సహజ వ్యవసాయం",
    "hi": "🌱 प्राकृतिक खेती"
  },
  "naturalPageSub": {
    "en": "Practical methods to improve soil health, biodiversity and farm resilience.",
    "te": "నేల ఆరోగ్యం, జీవ వైవిధ్యం మరియు వ్యవసాయ స్థిరత్వాన్ని మెరుగుపరచే ఆచరణాత్మక పద్ధతులు.",
    "hi": "मिट्टी स्वास्थ्य, जैव विविधता और खेती की स्थिरता सुधारने की व्यावहारिक पद्धतियाँ।"
  },
  "schemePageTitle": {
    "en": "🏛️ Government Schemes",
    "te": "🏛️ ప్రభుత్వ పథకాలు",
    "hi": "🏛️ सरकारी योजनाएँ"
  },
  "schemePageSub": {
    "en": "Major government programmes that can support farmers. Verify current eligibility on the official portal.",
    "te": "రైతులకు సహాయపడే ప్రధాన ప్రభుత్వ పథకాలు. ప్రస్తుత అర్హతను అధికారిక పోర్టల్‌లో నిర్ధారించండి.",
    "hi": "किसानों की सहायता करने वाली प्रमुख सरकारी योजनाएँ। वर्तमान पात्रता आधिकारिक पोर्टल पर जाँचें।"
  },
  "assistantPageTitle": {
    "en": "🎤 Farmer Voice Assistant",
    "te": "🎤 రైతు వాయిస్ సహాయకుడు",
    "hi": "🎤 किसान वॉइस सहायक"
  },
  "assistantPageSub": {
    "en": "Speak or type a simple farming question.",
    "te": "సులభమైన వ్యవసాయ ప్రశ్నను మాట్లాడండి లేదా టైప్ చేయండి.",
    "hi": "सरल कृषि प्रश्न बोलें या टाइप करें।"
  },
  "startListening": {
    "en": "Start Listening",
    "te": "వినడం ప్రారంభించండి",
    "hi": "सुनना शुरू करें"
  },
  "voiceReady": {
    "en": "Ready",
    "te": "సిద్ధంగా ఉంది",
    "hi": "तैयार"
  },
  "assistantPlaceholder": {
    "en": "Example: How should I manage rice pests?",
    "te": "ఉదాహరణ: వరి తెగుళ్లను ఎలా నిర్వహించాలి?",
    "hi": "उदाहरण: धान के कीटों का प्रबंधन कैसे करें?"
  },
  "askQuestion": {
    "en": "Ask Question",
    "te": "ప్రశ్న అడగండి",
    "hi": "प्रश्न पूछें"
  },
  "readAnswer": {
    "en": "🔊 Read Answer",
    "te": "🔊 సమాధానం చదవండి",
    "hi": "🔊 उत्तर पढ़ें"
  },
  "answerTitle": {
    "en": "Answer",
    "te": "సమాధానం",
    "hi": "उत्तर"
  },
  "answerDefault": {
    "en": "Ask a question about crops, pests, fertilizers, natural farming or government schemes.",
    "te": "పంటలు, తెగుళ్లు, ఎరువులు, సహజ వ్యవసాయం లేదా ప్రభుత్వ పథకాల గురించి ప్రశ్న అడగండి.",
    "hi": "फसलों, कीटों, उर्वरकों, प्राकृतिक खेती या सरकारी योजनाओं के बारे में प्रश्न पूछें।"
  },
  "assistantNoteTitle": {
    "en": "Note:",
    "te": "గమనిక:",
    "hi": "नोट:"
  },
  "assistantNote": {
    "en": "Voice recognition depends on browser support. Confirm chemical decisions with local agricultural advice.",
    "te": "వాయిస్ గుర్తింపు బ్రౌజర్ మద్దతుపై ఆధారపడి ఉంటుంది. రసాయనాల నిర్ణయాలను స్థానిక వ్యవసాయ సలహాతో నిర్ధారించండి.",
    "hi": "वॉइस पहचान ब्राउज़र समर्थन पर निर्भर करती है। रसायनों के निर्णय स्थानीय कृषि सलाह से सत्यापित करें।"
  },
  "helpPageTitle": {
    "en": "📞 Help & Farmer Guidance",
    "te": "📞 సహాయం & రైతు మార్గదర్శకత్వం",
    "hi": "📞 सहायता एवं किसान मार्गदर्शन"
  },
  "helpPageSub": {
    "en": "Useful guidance for using this website and getting local agricultural support.",
    "te": "ఈ వెబ్‌సైట్‌ను ఉపయోగించడానికి మరియు స్థానిక వ్యవసాయ సహాయం పొందడానికి ఉపయోగకరమైన మార్గదర్శకత్వం.",
    "hi": "इस वेबसाइट के उपयोग और स्थानीय कृषि सहायता के लिए उपयोगी मार्गदर्शन।"
  },
  "howUseTitle": {
    "en": "How to Use",
    "te": "ఎలా ఉపయోగించాలి",
    "hi": "कैसे उपयोग करें"
  },
  "howUseText": {
    "en": "Choose your language, open a section, select a crop or topic, and read the guidance.",
    "te": "భాషను ఎంచుకుని, ఒక విభాగాన్ని తెరిచి, పంట లేదా అంశాన్ని ఎంచుకుని మార్గదర్శకత్వాన్ని చదవండి.",
    "hi": "भाषा चुनें, अनुभाग खोलें, फसल या विषय चुनें और मार्गदर्शन पढ़ें।"
  },
  "localHelpTitle": {
    "en": "Local Support",
    "te": "స్థానిక సహాయం",
    "hi": "स्थानीय सहायता"
  },
  "localHelpText": {
    "en": "For exact pesticide or fertilizer dosage, contact your nearest agriculture department, Krishi Vigyan Kendra or qualified agronomist.",
    "te": "ఖచ్చితమైన పురుగుమందు లేదా ఎరువు మోతాదు కోసం సమీప వ్యవసాయ శాఖ, కృషి విజ్ఞాన కేంద్రం లేదా అర్హత కలిగిన వ్యవసాయ నిపుణుడిని సంప్రదించండి.",
    "hi": "सटीक कीटनाशक या उर्वरक मात्रा के लिए निकटतम कृषि विभाग, कृषि विज्ञान केंद्र या योग्य कृषि विशेषज्ञ से संपर्क करें।"
  },
  "safetyTitle": {
    "en": "Safety",
    "te": "భద్రత",
    "hi": "सुरक्षा"
  },
  "safetyText": {
    "en": "Never mix farm chemicals without label guidance. Wear protective equipment and keep products away from children and food.",
    "te": "లేబుల్ మార్గదర్శకం లేకుండా వ్యవసాయ రసాయనాలను కలపవద్దు. రక్షణ పరికరాలు ధరించి ఉత్పత్తులను పిల్లలు మరియు ఆహారం నుండి దూరంగా ఉంచండి.",
    "hi": "लेबल मार्गदर्शन के बिना कृषि रसायनों को न मिलाएँ। सुरक्षा उपकरण पहनें और उत्पादों को बच्चों व भोजन से दूर रखें।"
  },
  "websiteGoalTitle": {
    "en": "Project Goal",
    "te": "ప్రాజెక్ట్ లక్ష్యం",
    "hi": "परियोजना का लक्ष्य"
  },
  "websiteGoalText": {
    "en": "This student project brings crop information, pest awareness, natural farming, government schemes and a multilingual voice assistant into one simple platform for rural users.",
    "te": "ఈ విద్యార్థి ప్రాజెక్ట్ పంటల సమాచారం, తెగుళ్ల అవగాహన, సహజ వ్యవసాయం, ప్రభుత్వ పథకాలు మరియు బహుభాషా వాయిస్ సహాయకుడిని గ్రామీణ వినియోగదారుల కోసం ఒకే సరళమైన వేదికలో అందిస్తుంది.",
    "hi": "यह छात्र परियोजना ग्रामीण उपयोगकर्ताओं के लिए फसल जानकारी, कीट जागरूकता, प्राकृतिक खेती, सरकारी योजनाएँ और बहुभाषी वॉइस सहायक को एक सरल मंच पर लाती है।"
  }
};