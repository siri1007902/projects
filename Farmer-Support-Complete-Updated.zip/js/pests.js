const pestsData=[
  {
    "icon": "🐛",
    "name": {
      "en": "Stem Borer",
      "te": "కాండం తొలుచు పురుగు",
      "hi": "तना छेदक"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🦟",
    "name": {
      "en": "Aphids",
      "te": "ఆఫిడ్స్",
      "hi": "माहू"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🕷️",
    "name": {
      "en": "Thrips",
      "te": "త్రిప్స్",
      "hi": "थ्रिप्स"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🦋",
    "name": {
      "en": "Fruit / Pod Borer",
      "te": "ఫల / కాయ తొలుచు పురుగు",
      "hi": "फल / फली छेदक"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🍂",
    "name": {
      "en": "Leaf Spot",
      "te": "ఆకు మచ్చ",
      "hi": "पत्ती धब्बा"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🦠",
    "name": {
      "en": "Yellow Mosaic",
      "te": "పసుపు మొజాయిక్",
      "hi": "पीला मोजेक"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🪲",
    "name": {
      "en": "Whitefly",
      "te": "వైట్‌ఫ్లై",
      "hi": "सफेद मक्खी"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🪲",
    "name": {
      "en": "Shoot Borer",
      "te": "కొమ్మ తొలుచు పురుగు",
      "hi": "प्ररोह छेदक"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🦠",
    "name": {
      "en": "Wilt Disease",
      "te": "వాడిపోవు వ్యాధి",
      "hi": "उकठा रोग"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🦠",
    "name": {
      "en": "Bacterial Leaf Blight",
      "te": "బ్యాక్టీరియా ఆకు ఎండాకు",
      "hi": "बैक्टीरियल लीफ ब्लाइट"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🕷️",
    "name": {
      "en": "Mites",
      "te": "మైట్స్",
      "hi": "माइट्स"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  },
  {
    "icon": "🪱",
    "name": {
      "en": "Root / Soil Grubs",
      "te": "వేరు / నేల గ్రబ్స్",
      "hi": "जड़ / मिट्टी के ग्रब"
    },
    "symptoms": {
      "en": "Leaves, shoots or fruits show characteristic damage; inspect affected plant parts closely.",
      "te": "ఆకులు, కొమ్మలు లేదా ఫలాల్లో నష్టం కనిపిస్తుంది; ప్రభావిత భాగాలను జాగ్రత్తగా పరిశీలించండి.",
      "hi": "पत्तियों, प्ररोह या फलों पर नुकसान दिखता है; प्रभावित भागों की जाँच करें।"
    },
    "management": {
      "en": "Use field sanitation, monitoring, biological/IPM methods and registered products only when recommended.",
      "te": "పొలం పరిశుభ్రత, పర్యవేక్షణ, జీవ/IPM పద్ధతులు మరియు సిఫార్సు చేసిన నమోదైన ఉత్పత్తులను మాత్రమే వాడండి.",
      "hi": "खेत की स्वच्छता, निगरानी, जैव/IPM पद्धतियाँ और सलाह पर पंजीकृत उत्पाद उपयोग करें।"
    }
  }
];const pestLabels={en:{symptoms:"Symptoms",management:"Management"},te:{symptoms:"లక్షణాలు",management:"నిర్వహణ"},hi:{symptoms:"लक्षण",management:"प्रबंधन"}};function renderPests(){let l=getCurrentLanguage(),q=(document.getElementById("pestSearch").value||"").toLowerCase(),list=pestsData.filter(p=>[p.name.en,p.name.te,p.name.hi].some(v=>v.toLowerCase().includes(q)));document.getElementById("pestGrid").innerHTML=list.map(p=>`<article class="card"><div class="crop-top"><div class="crop-icon">${p.icon}</div><h2>${p.name[l]}</h2></div><p><b>${pestLabels[l].symptoms}:</b> ${p.symptoms[l]}</p><p><b>${pestLabels[l].management}:</b> ${p.management[l]}</p></article>`).join("")}document.addEventListener("DOMContentLoaded",()=>{renderPests();document.getElementById("pestSearch").oninput=renderPests;document.addEventListener("languageChanged",renderPests)});