const naturalItems=[
  {
    "icon": "🌱",
    "name": {
      "en": "Soil Testing & Observation",
      "te": "నేల పరీక్ష & పరిశీలన",
      "hi": "मिट्टी परीक्षण और निरीक्षण"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🐄",
    "name": {
      "en": "Farmyard Manure",
      "te": "పశువుల ఎరువు",
      "hi": "गोबर की खाद"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🧪",
    "name": {
      "en": "Jeevamrut / Microbial Inputs",
      "te": "జీవామృతం / సూక్ష్మజీవ ఇన్‌పుట్లు",
      "hi": "जीवामृत / सूक्ष्मजीव इनपुट"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🍂",
    "name": {
      "en": "Mulching",
      "te": "మల్చింగ్",
      "hi": "मल्चिंग"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🌾",
    "name": {
      "en": "Crop Rotation",
      "te": "పంట మార్పిడి",
      "hi": "फसल चक्र"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🌼",
    "name": {
      "en": "Intercropping",
      "te": "అంతర పంట",
      "hi": "अंतरफसल"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🐝",
    "name": {
      "en": "Beneficial Insects",
      "te": "ఉపయోగకర కీటకాలు",
      "hi": "लाभकारी कीट"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "💧",
    "name": {
      "en": "Water Conservation",
      "te": "నీటి సంరక్షణ",
      "hi": "जल संरक्षण"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "🌿",
    "name": {
      "en": "Botanical Preparations",
      "te": "వృక్ష ఆధారిత తయారీలు",
      "hi": "वनस्पति आधारित तैयारियाँ"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  },
  {
    "icon": "♻️",
    "name": {
      "en": "Farm Waste Recycling",
      "te": "వ్యవసాయ వ్యర్థాల పునర్వినియోగం",
      "hi": "कृषि अवशेष पुनर्चक्रण"
    },
    "text": {
      "en": "Improve soil health and reduce avoidable inputs using a practical, locally suitable approach.",
      "te": "స్థానిక పరిస్థితులకు అనుకూలమైన పద్ధతులతో నేల ఆరోగ్యాన్ని మెరుగుపరచి అవసరం లేని ఇన్‌పుట్‌లను తగ్గించండి.",
      "hi": "स्थानीय परिस्थितियों के अनुसार मिट्टी स्वास्थ्य सुधारें और अनावश्यक इनपुट कम करें।"
    }
  }
];function renderNatural(){let l=getCurrentLanguage();document.getElementById("naturalGrid").innerHTML=naturalItems.map(i=>`<article class="card"><div class="crop-icon">${i.icon}</div><h2>${i.name[l]}</h2><p>${i.text[l]}</p></article>`).join("")}document.addEventListener("DOMContentLoaded",()=>{renderNatural();document.addEventListener("languageChanged",renderNatural)});