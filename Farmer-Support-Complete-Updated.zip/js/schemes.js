const schemes=[
  {
    "icon": "💰",
    "name": {
      "en": "PM-KISAN",
      "te": "పీఎం-కిసాన్",
      "hi": "पीएम-किसान"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://pmkisan.gov.in/"
  },
  {
    "icon": "🛡️",
    "name": {
      "en": "Pradhan Mantri Fasal Bima Yojana",
      "te": "ప్రధాన మంత్రి ఫసల్ బీమా యోజన",
      "hi": "प्रधानमंत्री फसल बीमा योजना"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://pmfby.gov.in/"
  },
  {
    "icon": "🏦",
    "name": {
      "en": "Kisan Credit Card",
      "te": "కిసాన్ క్రెడిట్ కార్డ్",
      "hi": "किसान क्रेडिट कार्ड"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://www.myscheme.gov.in/"
  },
  {
    "icon": "🧪",
    "name": {
      "en": "Soil Health Card Scheme",
      "te": "సాయిల్ హెల్త్ కార్డ్ పథకం",
      "hi": "मृदा स्वास्थ्य कार्ड योजना"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://soilhealth.dac.gov.in/"
  },
  {
    "icon": "💧",
    "name": {
      "en": "Pradhan Mantri Krishi Sinchayee Yojana",
      "te": "ప్రధాన మంత్రి కృషి సించాయీ యోజన",
      "hi": "प्रधानमंत्री कृषि सिंचाई योजना"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://pmksy.gov.in/"
  },
  {
    "icon": "☀️",
    "name": {
      "en": "PM-KUSUM",
      "te": "పీఎం-కుసుమ్",
      "hi": "पीएम-कुसुम"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://pmkusum.mnre.gov.in/"
  },
  {
    "icon": "🛒",
    "name": {
      "en": "e-NAM",
      "te": "ఈ-నామ్",
      "hi": "ई-नाम"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://www.enam.gov.in/"
  },
  {
    "icon": "🌱",
    "name": {
      "en": "Paramparagat Krishi Vikas Yojana",
      "te": "పరంపరాగత కృషి వికాస్ యోజన",
      "hi": "परम्परागत कृषि विकास योजना"
    },
    "description": {
      "en": "Government support programme for eligible farmers or agricultural activities under current rules.",
      "te": "ప్రస్తుత నియమాల ప్రకారం అర్హత కలిగిన రైతులు లేదా వ్యవసాయ కార్యకలాపాలకు ప్రభుత్వ సహాయ కార్యక్రమం.",
      "hi": "वर्तमान नियमों के अनुसार पात्र किसानों या कृषि गतिविधियों के लिए सरकारी सहायता कार्यक्रम।"
    },
    "benefits": {
      "en": "Benefits depend on the scheme component, state and current guidelines.",
      "te": "ప్రయోజనాలు పథకం భాగం, రాష్ట్రం మరియు ప్రస్తుత మార్గదర్శకాలపై ఆధారపడి ఉంటాయి.",
      "hi": "लाभ योजना के घटक, राज्य और वर्तमान दिशा-निर्देशों पर निर्भर हैं।"
    },
    "eligibility": {
      "en": "Check current eligibility, documents and application process on the official portal.",
      "te": "ప్రస్తుత అర్హత, పత్రాలు మరియు దరఖాస్తు ప్రక్రియను అధికారిక పోర్టల్‌లో చూడండి.",
      "hi": "वर्तमान पात्रता, दस्तावेज और आवेदन प्रक्रिया आधिकारिक पोर्टल पर देखें।"
    },
    "website": "https://pgsindia-ncof.gov.in/"
  }
];const schemeLabels={en:{description:"Description",benefits:"Benefits",eligibility:"Eligibility",website:"Official Website",visit:"Visit Official Website"},te:{description:"వివరణ",benefits:"ప్రయోజనాలు",eligibility:"అర్హత",website:"అధికారిక వెబ్‌సైట్",visit:"అధికారిక వెబ్‌సైట్‌ను సందర్శించండి"},hi:{description:"विवरण",benefits:"लाभ",eligibility:"पात्रता",website:"आधिकारिक वेबसाइट",visit:"आधिकारिक वेबसाइट देखें"}};function displaySchemes(){let l=getCurrentLanguage(),x=schemeLabels[l];document.getElementById("schemesContainer").innerHTML=schemes.map(s=>`<article class="card scheme-card"><div class="crop-top"><div class="crop-icon">${s.icon}</div><h2>${s.name[l]}</h2></div><p><b>${x.description}:</b> ${s.description[l]}</p><p><b>${x.benefits}:</b> ${s.benefits[l]}</p><p><b>${x.eligibility}:</b> ${s.eligibility[l]}</p><p><b>${x.website}:</b></p><a class="btn small" href="${s.website}" target="_blank" rel="noopener">${x.visit} ↗</a></article>`).join("")}document.addEventListener("DOMContentLoaded",()=>{displaySchemes();document.addEventListener("languageChanged",displaySchemes)});