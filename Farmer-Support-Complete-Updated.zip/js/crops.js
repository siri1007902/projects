const crops=[
  {
    "icon": "🌾",
    "name": {
      "en": "Rice",
      "te": "వరి",
      "hi": "धान"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🌽",
    "name": {
      "en": "Maize",
      "te": "మొక్కజొన్న",
      "hi": "मक्का"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🥜",
    "name": {
      "en": "Groundnut",
      "te": "వేరుశెనగ",
      "hi": "मूंगफली"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "☁️",
    "name": {
      "en": "Cotton",
      "te": "పత్తి",
      "hi": "कपास"
    },
    "season": {
      "en": "Kharif",
      "te": "ఖరీఫ్",
      "hi": "खरीफ"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🎋",
    "name": {
      "en": "Sugarcane",
      "te": "చెరకు",
      "hi": "गन्ना"
    },
    "season": {
      "en": "Varies by region",
      "te": "ప్రాంతాన్ని బట్టి మారుతుంది",
      "hi": "क्षेत्र के अनुसार बदलता है"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🌶️",
    "name": {
      "en": "Chilli",
      "te": "మిరప",
      "hi": "मिर्च"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🟠",
    "name": {
      "en": "Turmeric",
      "te": "పసుపు",
      "hi": "हल्दी"
    },
    "season": {
      "en": "Kharif",
      "te": "ఖరీఫ్",
      "hi": "खरीफ"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🫘",
    "name": {
      "en": "Red Gram",
      "te": "కందులు",
      "hi": "अरहर"
    },
    "season": {
      "en": "Kharif",
      "te": "ఖరీఫ్",
      "hi": "खरीफ"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🫘",
    "name": {
      "en": "Black Gram",
      "te": "మినుములు",
      "hi": "उड़द"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🫘",
    "name": {
      "en": "Green Gram",
      "te": "పెసలు",
      "hi": "मूंग"
    },
    "season": {
      "en": "Kharif / Rabi",
      "te": "ఖరీఫ్ / రబీ",
      "hi": "खरीफ / रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🫘",
    "name": {
      "en": "Bengal Gram",
      "te": "శనగ",
      "hi": "चना"
    },
    "season": {
      "en": "Rabi",
      "te": "రబీ",
      "hi": "रबी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🍅",
    "name": {
      "en": "Tomato",
      "te": "టమాటా",
      "hi": "टमाटर"
    },
    "season": {
      "en": "Kharif / Rabi / Summer",
      "te": "ఖరీఫ్ / రబీ / వేసవి",
      "hi": "खरीफ / रबी / गर्मी"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🧅",
    "name": {
      "en": "Onion",
      "te": "ఉల్లి",
      "hi": "प्याज"
    },
    "season": {
      "en": "Rabi / Kharif",
      "te": "రబీ / ఖరీఫ్",
      "hi": "रबी / खरीफ"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🍌",
    "name": {
      "en": "Banana",
      "te": "అరటి",
      "hi": "केला"
    },
    "season": {
      "en": "Year-round in suitable climate",
      "te": "అనుకూల వాతావరణంలో ఏడాది పొడవునా",
      "hi": "उपयुक्त जलवायु में साल भर"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  },
  {
    "icon": "🥥",
    "name": {
      "en": "Coconut",
      "te": "కొబ్బరి",
      "hi": "नारियल"
    },
    "season": {
      "en": "Year-round in suitable areas",
      "te": "అనుకూల ప్రాంతాల్లో ఏడాది పొడవునా",
      "hi": "उपयुक्त क्षेत्रों में साल भर"
    },
    "soil": {
      "en": "Well-drained loam or suitable local soil",
      "te": "మంచి పారుదల గల లోమీ లేదా స్థానికంగా అనుకూల నేల",
      "hi": "अच्छी जल निकासी वाली दोमट या स्थानीय उपयुक्त मिट्टी"
    },
    "water": {
      "en": "Maintain soil moisture and avoid prolonged waterlogging.",
      "te": "నేల తేమను నిర్వహించి దీర్ఘకాల నీరు నిల్వను నివారించండి.",
      "hi": "मिट्टी की नमी बनाए रखें और लंबे जलभराव से बचें।"
    },
    "fertilizer": {
      "en": "Use soil-test-based balanced nutrients and organic matter.",
      "te": "నేల పరీక్ష ఆధారంగా సమతుల పోషకాలు మరియు సేంద్రియ పదార్థం వాడండి.",
      "hi": "मिट्टी परीक्षण आधारित संतुलित पोषक तत्व और जैविक पदार्थ उपयोग करें।"
    },
    "pesticide": {
      "en": "Monitor pests first; use registered products only when needed and follow the label/local recommendation.",
      "te": "ముందుగా తెగుళ్లను పర్యవేక్షించండి; అవసరమైనప్పుడు మాత్రమే నమోదైన ఉత్పత్తిని లేబుల్/స్థానిక సిఫార్సు ప్రకారం వాడండి.",
      "hi": "पहले कीट निगरानी करें; जरूरत पर ही पंजीकृत उत्पाद लेबल/स्थानीय सलाह के अनुसार उपयोग करें।"
    },
    "practices": {
      "en": "Good seed selection, weed control, balanced nutrition, timely irrigation and harvest.",
      "te": "మంచి విత్తన ఎంపిక, కలుపు నియంత్రణ, సమతుల పోషణ, సమయానుకూల నీరు మరియు కోత.",
      "hi": "अच्छे बीज का चयन, खरपतवार नियंत्रण, संतुलित पोषण, समय पर सिंचाई और कटाई।"
    }
  }
];
const cropLabels={en:{season:"Season",soil:"Soil",water:"Water",fertilizer:"Fertilizers",pesticide:"Pesticides",practices:"Good Practices"},te:{season:"కాలం",soil:"నేల",water:"నీరు",fertilizer:"ఎరువులు",pesticide:"పురుగుమందులు",practices:"మంచి పద్ధతులు"},hi:{season:"मौसम",soil:"मिट्टी",water:"पानी",fertilizer:"उर्वरक",pesticide:"कीटनाशक",practices:"अच्छी पद्धतियाँ"}};function renderCrops(){let l=getCurrentLanguage(),q=(document.getElementById("cropSearch").value||"").toLowerCase(),s=document.getElementById("cropSelect");if(s.options.length===1)crops.forEach(c=>{let o=document.createElement("option");o.value=c.name.en;o.textContent=c.icon+" "+c.name[l];s.appendChild(o)});else [...s.options].forEach((o,i)=>{if(i)o.textContent=crops[i-1].icon+" "+crops[i-1].name[l]});let chosen=s.value, list=crops.filter(c=>!chosen||c.name.en===chosen).filter(c=>!q||[c.name.en,c.name.te,c.name.hi].some(v=>v.toLowerCase().includes(q)));document.getElementById("cropGrid").innerHTML=list.map(c=>`<article class="card crop-card"><div class="crop-top"><div class="crop-icon">${c.icon}</div><h2>${c.name[l]}</h2></div><p><b>${cropLabels[l].season}:</b> ${c.season[l]}</p><p><b>${cropLabels[l].soil}:</b> ${c.soil[l]}</p><p><b>${cropLabels[l].water}:</b> ${c.water[l]}</p><p><b>${cropLabels[l].fertilizer}:</b> ${c.fertilizer[l]}</p><p><b>${cropLabels[l].pesticide}:</b> ${c.pesticide[l]}</p><p><b>${cropLabels[l].practices}:</b> ${c.practices[l]}</p></article>`).join("")}document.addEventListener("DOMContentLoaded",()=>{renderCrops();document.getElementById("cropSearch").oninput=renderCrops;document.getElementById("cropSelect").onchange=renderCrops;document.addEventListener("languageChanged",renderCrops)});